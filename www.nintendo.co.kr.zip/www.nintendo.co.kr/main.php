
<!doctype html>
<html lang="ko">
<head>
    <title>Nintendo</title>
    <meta name="description" content="콘솔 게임기 전문업체, Nintendo Switch, 게임 소프트웨어 등 제품 소개, 약도 제공.">
    <meta charset="utf-8">
    <meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1.0, user-scalable=no, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="format-detection" content="telephone=no">

    <!-- favicon -->
    <link rel="shortcut icon" href="/favicon.ico">

    <!-- touch icon -->
    <link rel="apple-touch-icon-precomposed" href="apple-touch-icon-precomposed.png">

    <!-- style -->
    <link href="/css/owl.carousel.min.css" type="text/css" rel="stylesheet">
    <link href="/css/owl.theme.default.min.css" type="text/css" rel="stylesheet">
    <link href="/css/common.css?v=201805311412" type="text/css" rel="stylesheet">
    <link href="/css/main.css?v=201712051050" type="text/css" rel="stylesheet">
    <link href="/css/amiibo.css" type="text/css" rel="stylesheet">
    <link href="/css/3ds.css?v=201712041503" type="text/css" rel="stylesheet">
    <link href="/css/software.css?v=201806141730" type="text/css" rel="stylesheet">
    <link href="/css/etc.css" type="text/css" rel="stylesheet">
    <!-- 플로팅 버튼용 css 20.08.12 -->
    <link href="/css/main-purchase.css" rel="stylesheet">

    <!-- script -->
    <script src="/js/renew/jquery-1.12.0.min.js"></script>
    <script src="/js/renew/jquery-migrate-1.2.1.min.js"></script>
    <script src="/js/renew/owl.carousel.min.js"></script>
    <script src="/js/renew/TweenMax.min.js"></script>
    <script src="/js/renew/jquery.ellipsis.min.js"></script>
    <script src="/js/renew/ui.js"></script>

    <!-- 20.07.01 다운로드 구입 버튼 클릭 수 집계 스크립트 -->
    <script language='javascript'>var _bAce1=[];function ACEL_TRACKING_1(mode,ename,tgurl,tg){ var ACEL_img_1 = new Image();var ACED_D = 'gtm1.acecounter.com';var ACED_H=(location.protocol=='https:')?'https://'+ACED_D+':5443':'http://'+ACED_D+':5656';ACEL_img_1.src = ACED_H + '/EMAM?euid=AH3A39994163732&ename='+ename+'&fdv='+mode+'&RID='+Math.random()+'&';if(typeof(Array.prototype.push)!='undefined'){_bAce1.push(ACEL_img_1);}; if(typeof tg=='undefined'){ var tg='';};if(typeof tga=='undefined'){ var tga='';}; if(typeof tgurl=='undefined'){ var tgurl='';}; if(mode != 'BV'){ if(tgurl!=''){ if( tg!=''){window.open(tgurl,tg,tga);}else{location.href=tgurl;};};};};</script><script>if(typeof ACEL_TRACKING_1=='function') ACEL_TRACKING_1('BV','1');</script>
    <script language='javascript'>var _bAce9=[];function ACEL_TRACKING_9(mode,ename,tgurl,tg){ var ACEL_img_9 = new Image();var ACED_D = 'gtm1.acecounter.com';var ACED_H=(location.protocol=='https:')?'https://'+ACED_D+':5443':'http://'+ACED_D+':5656';ACEL_img_9.src = ACED_H + '/EMAM?euid=AH3A39994163732&ename='+ename+'&fdv='+mode+'&RID='+Math.random()+'&';if(typeof(Array.prototype.push)!='undefined'){_bAce9.push(ACEL_img_9);}; if(typeof tg=='undefined'){ var tg='';};if(typeof tga=='undefined'){ var tga='';}; if(typeof tgurl=='undefined'){ var tgurl='';}; if(mode != 'BV'){ if(tgurl!=''){ if( tg!=''){window.open(tgurl,tg,tga);}else{location.href=tgurl;};};};};</script><script>if(typeof ACEL_TRACKING_9=='function') ACEL_TRACKING_9('BV','9');</script>
    <script language='javascript'>var _bAce10=[];function ACEL_TRACKING_10(mode,ename,tgurl,tg){ var ACEL_img_10 = new Image();var ACED_D = 'gtm1.acecounter.com';var ACED_H=(location.protocol=='https:')?'https://'+ACED_D+':5443':'http://'+ACED_D+':5656';ACEL_img_10.src = ACED_H + '/EMAM?euid=AH3A39994163732&ename='+ename+'&fdv='+mode+'&RID='+Math.random()+'&';if(typeof(Array.prototype.push)!='undefined'){_bAce10.push(ACEL_img_10);}; if(typeof tg=='undefined'){ var tg='';};if(typeof tga=='undefined'){ var tga='';}; if(typeof tgurl=='undefined'){ var tgurl='';}; if(mode != 'BV'){ if(tgurl!=''){ if( tg!=''){window.open(tgurl,tg,tga);}else{location.href=tgurl;};};};};</script><script>if(typeof ACEL_TRACKING_10=='function') ACEL_TRACKING_10('BV','10');</script>

    <!-- 20.08.19 플로팅 버튼 클릭 수 집계 스크립트 -->
    <script language='javascript'>var _bAce11=[];function ACEL_TRACKING_11(mode,ename,tgurl,tg){ var ACEL_img_11 = new Image();var ACED_D = 'gtm1.acecounter.com';var ACED_H=(location.protocol=='https:')?'https://'+ACED_D+':5443':'http://'+ACED_D+':5656';ACEL_img_11.src = ACED_H + '/EMAM?euid=AH3A39994163732&ename='+ename+'&fdv='+mode+'&RID='+Math.random()+'&';if(typeof(Array.prototype.push)!='undefined'){_bAce11.push(ACEL_img_11);}; if(typeof tg=='undefined'){ var tg='';};if(typeof tga=='undefined'){ var tga='';}; if(typeof tgurl=='undefined'){ var tgurl='';}; if(mode != 'BV'){ if(tgurl!=''){ if( tg!=''){window.open(tgurl,tg,tga);}else{location.href=tgurl;};};};};</script><script>if(typeof ACEL_TRACKING_11=='function') ACEL_TRACKING_11('BV','11');</script>
    <script language='javascript'>var _bAce12=[];function ACEL_TRACKING_12(mode,ename,tgurl,tg){ var ACEL_img_12 = new Image();var ACED_D = 'gtm1.acecounter.com';var ACED_H=(location.protocol=='https:')?'https://'+ACED_D+':5443':'http://'+ACED_D+':5656';ACEL_img_12.src = ACED_H + '/EMAM?euid=AH3A39994163732&ename='+ename+'&fdv='+mode+'&RID='+Math.random()+'&';if(typeof(Array.prototype.push)!='undefined'){_bAce12.push(ACEL_img_12);}; if(typeof tg=='undefined'){ var tg='';};if(typeof tga=='undefined'){ var tga='';}; if(typeof tgurl=='undefined'){ var tgurl='';}; if(mode != 'BV'){ if(tgurl!=''){ if( tg!=''){window.open(tgurl,tg,tga);}else{location.href=tgurl;};};};};</script><script>if(typeof ACEL_TRACKING_12=='function') ACEL_TRACKING_12('BV','12');</script>

    <!-- Global site tag (gtag.js) - Google Analytics 2021.05.28 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-TZJWWLH4VJ"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-198084078-1');
        gtag('config', 'G-TZJWWLH4VJ');
    </script>

    <style>
        .menu_pc {display: list-item;}
        .menu_mo {display: none;}

        @media screen and (max-width: 1220px) {
            .menu_pc {display: none;}
            .menu_mo {display: list-item;}
        }
    </style>
</head>

<body class="main-purchase">
<!-- header -->
<header>
    <h1><a href="/main.php">Nintendo</a></h1>
    <nav>
        <ul>
            <li>
                <a href="/switch/top.php"> Nintendo Switch</a>
                <ul>
                    <li class="menu_pc"><a href="/switch/feature.php">특징</a></li>
                    <li class="menu_mo"><a href="/switch/feature.php">Nintendo Switch</a></li>
                    <li><a href="/switch/lite/index.php">Nintendo Switch Lite</a></li>
                    <li><a href="/switch/compare/index.php">어떤 Switch?</a></li>
                    <li><a href="/switch/lineup/index.php">라인업</a></li>
                    <li><a href="/switch/specs/index.php">기능ㆍ사양</a></li>
                    <li><a href="/switch/accessories/index.php">주변기기</a></li>
                    <li><a href="/switch/onlineservice/index.php">Nintendo Switch Online</a></li>
                    <li><a href="/switch/parentalcontrols/index.php">Nintendo 지킴이 Switch&trade;</a></li>
                    <li><a href="/support/switch/eshop/index.php">닌텐도 e숍</a></li>
                </ul>
            </li>
            <li>
                <a href="/n3ds/index.php"> 닌텐도 3DS</a>
                <ul>
                    <li><a href="/n3ds/index.php">닌텐도 3DS란?</a></li>
                    <li><a href="/n3ds/new_3dsXl.php">New 닌텐도 3DS XL</a></li>
                    <li><a href="/n3ds/new_2dsXl.php">New 닌텐도 2DS XL</a></li>
                    <li><a href="/n3ds/others.php">기타 시리즈</a></li>
                    <li><a href="/software/software_eshop.php">닌텐도 e숍</a></li>
                </ul>
            </li>
            <li>
                <a href="/software/switch/index.php">소프트웨어</a>
                <ul>
                    <li><a href="/software/switch/index.php">Nintendo Switch 소프트웨어</a></li>
                    <li><a href="/software/3ds/index.php">닌텐도 3DS 소프트웨어</a></li>
                    <li><a href="/software/release">발매 예정 소프트웨어</a></li>
                    <li><a href="/software/smartphone">스마트폰용 앱</a></li>
                </ul>
            </li>
            <li>
                <a href="/support/index.php">고객지원</a>
                <ul>
                    <li><a href="/support/switch/index.php">Nintendo Switch 고객지원</a></li>
                    <li><a href="/support/switch/nintendo_switch_online/">Nintendo Switch Online 서포트</a></li>
                    <li><a href="/3DS/customer/index.php">닌텐도 3DS 고객지원</a></li>
                    <li><a href="https://support.nintendo.co.kr/index.do">고객지원 홈페이지</a></li>
                    <li><a href="https://www.nintendo.co.jp/netinfo/ko_KR/index.html" target="_blank">네트워크 장애 발생 상황</a></li>
                </ul>
            </li>
            <li>
                <a href="/news/list.php">News</a>
                <ul>
                    <li><a href="/news/list.php?cate=1">News</a></li>
                    <li><a href="/news/list.php?cate=2">보도자료</a></li>
                    <li><a href="/news/list.php?cate=3">알림</a></li>
                    <li><a href="/news/list.php?cate=4">이벤트</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <a href="#" class="btn_gnb is-folded">메뉴 열기/닫기</a>
    <a href="https://store.nintendo.co.kr/" onmousedown="javascript:ACEL_TRACKING_1('BC','1');" class="btn_eshop" target="_blank">다운로드 구입</a>
    <a href="#" class="btn_search">검색</a>
    <div class="box_search">
        <form action="/search.php" method="get" id="globalSearchFrm" accept-charset="utf-8">
		<span>
			<input type="text" name="globalSearch" placeholder="키워드를 입력해주세요." />
			<a href="javascript:globalSearch()">검 색</a>
		</span>
        </form>
        <a href="#" class="btn_close_searchBox">검색 닫기</a>
    </div>
</header>
<!-- //header -->
<script type="text/javascript">
    function globalSearch(){
        $("#globalSearchFrm").submit();
    }
</script>

<link href="/css/animate.css" rel="stylesheet" />
<script src="/lib/js/software.js"></script>

<style>
    .videoWrap {position:relative;padding-bottom:53%;padding-top:30px;height:0;overflow:hidden;}
    .videoWrap iframe, .videoWrap object, .videoWrap embed {position:absolute;top:0;left:0;width:100%;height:100%;}
    footer {margin-bottom: 0 !important;}
</style>



<section class="contents main">
    <div class="main_slide owl-carousel owl-theme">
                    <div class="item" data-num="1">
                <a href="/software/switch/aw8sa/" >
                    <img src="/front_images/banner/rolling/87/f5506a62f7abd298aa938379365bd100.png" class="pc_img" alt="">
                    <img src="/front_images/banner/rolling/87/858735ca9a899df9ffebddb870b3bca3.png" class="mobile_img" alt="">
                </a>
            </div>
                    <div class="item" data-num="2">
                <a href="/software/switch/awuxa/" >
                    <img src="/front_images/banner/rolling/87/86c950da670a185447aa62890aaeaf74.jpg" class="pc_img" alt="">
                    <img src="/front_images/banner/rolling/87/7962ec7b8d5b858c1ebd0c236cf3cc46.jpg" class="mobile_img" alt="">
                </a>
            </div>
                    <div class="item" data-num="3">
                <a href="/software/switch/at9ha/" >
                    <img src="/front_images/banner/rolling/87/100ec1bce06baaa87d5f9bb39c23510b.jpg" class="pc_img" alt="">
                    <img src="/front_images/banner/rolling/87/a1628d74efc856fd4f700ccb948c40d9.jpg" class="mobile_img" alt="">
                </a>
            </div>
                    <div class="item" data-num="4">
                <a href="https://www.pokemonkorea.co.kr/" target="_blank">
                    <img src="/front_images/banner/rolling/87/735693fd7c772ce06886e837c92ef9b9.jpeg" class="pc_img" alt="">
                    <img src="/front_images/banner/rolling/87/2957c695d1ffedbf1fca5e790debd9b8.jpeg" class="mobile_img" alt="">
                </a>
            </div>
                    <div class="item" data-num="5">
                <a href="/switch/lite/index.php" >
                    <img src="/front_images/banner/rolling/87/fac699f3dc0981ce4f74d39ce3753c68.jpeg" class="pc_img" alt="">
                    <img src="/front_images/banner/rolling/87/97f029dcff26e820e8dfa19aba38cccb.jpeg" class="mobile_img" alt="">
                </a>
            </div>
                    <div class="item" data-num="6">
                <a href="/software/switch/detail/arfta/" >
                    <img src="/front_images/banner/rolling/87/a3a2f6b92655c2ca3ad4905fe53010fb.jpg" class="pc_img" alt="">
                    <img src="/front_images/banner/rolling/87/6da85dc475380f00eca3791813500b88.jpg" class="mobile_img" alt="">
                </a>
            </div>
                    <div class="item" data-num="7">
                <a href="/software/switch/detail/axsea/" >
                    <img src="/front_images/banner/rolling/87/1d9b0dbae98f522dcb5527c326388217.jpeg" class="pc_img" alt="">
                    <img src="/front_images/banner/rolling/87/9c1ad4d208f5b18de66d18463a1576b6.jpeg" class="mobile_img" alt="">
                </a>
            </div>
                    <div class="item" data-num="8">
                <a href="/software/switch/acbaa/" >
                    <img src="/front_images/banner/rolling/87/acada5024447b521e2de013a8ffd69f3.jpg" class="pc_img" alt="">
                    <img src="/front_images/banner/rolling/87/0be2234385d467d336b699fb088aa170.jpg" class="mobile_img" alt="">
                </a>
            </div>
        

    </div>

    <!-- 슬라이드 페이지 카운팅  -->
    <div class="num-nav pcOnly">
        <span class="now">1</span> / <span class="maxLength"></span>
    </div>
    <!-- //main slide end -->


    <div class="news_list article">
        <h2 class="main_h2">새롭게 알려 드립니다<span class="desc">News &amp; Update</span></h2>

        <div class="newSw_cate board_news typeB">
                            <div class="item sw_item">
                    <a href="/news/view.php?no=bi9ZLytEMm9tRHdiVUZNbm9pUDVvQT09" class="thumb" target="_self"><img src="/front_images/news/699/1da035720abbca9b58984247d04622ab.jpg" alt="" loading="lazy"></a>
                    <div>
                        <span class="cate">뉴스</span>
                    </div>
                    <p class="tit">은하계를 구하기 위한 임무를 맡은 마리오, 래비드와 친구들에게 합류하세요!</p>
                    <p class="releaseInfo">2021.06.14<br>Nintendo Switch</p>
                </div>
                            <div class="item sw_item">
                    <a href="/software/switch/awuxa/" class="thumb" target="_self"><img src="/front_images/news/698/2ac26655a00732fe7a982d1f34189514.jpg" alt="" loading="lazy"></a>
                    <div>
                        <span class="cate">뉴스</span>
                    </div>
                    <p class="tit">『차근차근 게임 코딩』 다운로드 버전이 오늘 발매되었습니다. 체험판도 배포 중!</p>
                    <p class="releaseInfo">2021.06.11<br>Nintendo Switch</p>
                </div>
                            <div class="item sw_item">
                    <a href="/software/switch/at9ha/" class="thumb" target="_self"><img src="/front_images/news/696/66fc86c2c26a69e6f9d069803d30c207.jpeg" alt="" loading="lazy"></a>
                    <div>
                        <span class="cate">뉴스</span>
                    </div>
                    <p class="tit">「마리오 골프 슈퍼 러시」의 공식 소개 페이지가 공개되었습니다.</p>
                    <p class="releaseInfo">2021.06.04<br>Nintendo Switch</p>
                </div>
                            <div class="item sw_item">
                    <a href="https://youtube.com/playlist?list=PL4GwDymg3a1Sf5L28aOvoNoIgMS3dUh1y" class="thumb" target="_blank"><img src="/front_images/news/695/647d4ecbf501f556a76ce15f7ca7fdbf.png" alt="" loading="lazy"></a>
                    <div>
                        <span class="cate">뉴스</span>
                    </div>
                    <p class="tit">『미토피아』의 새로운 CM 2편이 공개되었습니다!</p>
                    <p class="releaseInfo">2021.06.01<br>Nintendo Switch</p>
                </div>
                            <div class="item sw_item">
                    <a href="/news/view.php?no=SmtQQ2o2KzIrOHFjMVFDeGYwOU8vdz09" class="thumb" target="_self"><img src="/front_images/news/694/411b42f4e3d160ae53fcf253638d120a.jpg" alt="" loading="lazy"></a>
                    <div>
                        <span class="cate">보도자료</span>
                    </div>
                    <p class="tit">한국닌텐도, 완전 신작 어드벤처 게임 『버디 미션 BOND』 올 여름 한글화 발매 결정!</p>
                    <p class="releaseInfo">2021.05.31<br>Nintendo Switch</p>
                </div>
                            <div class="item sw_item">
                    <a href="/news/view.php?no=dDBVVFMwZ0JqMUo4cjc3dmZTUkxDZz09" class="thumb" target="_self"><img src="/front_images/news/693/461af9613c23a1c530dcab0e4bf7a804.jpg" alt="" loading="lazy"></a>
                    <div>
                        <span class="cate">뉴스</span>
                    </div>
                    <p class="tit">「영묘한 광채의 발파루크」, 「주인 진오우거」가 등장! 『MONSTER HUNTER RISE』의 무료 타이틀 업데이트를 배포 시작.</p>
                    <p class="releaseInfo">2021.05.27<br>Nintendo Switch</p>
                </div>
                            <div class="item sw_item">
                    <a href="/news/view.php?no=TWI5L2dSSHczVU9hR2xKNmtwYmh3UT09" class="thumb" target="_self"><img src="/front_images/news/692/acea360b88cccdc920901b5bfc299c67.jpg" alt="" loading="lazy"></a>
                    <div>
                        <span class="cate">뉴스</span>
                    </div>
                    <p class="tit">새로운 정보가 가득한 『몬스터헌터 스토리즈 2 파멸의 날개』 프로모션 영상 ④ 공개!</p>
                    <p class="releaseInfo">2021.05.27<br>Nintendo Switch</p>
                </div>
                            <div class="item sw_item">
                    <a href="https://www.pokemonkorea.co.kr/" class="thumb" target="_blank"><img src="/front_images/news/691/d8f182c7d659a0c64d99976cfe4cc294.jpg" alt="" loading="lazy"></a>
                    <div>
                        <span class="cate">뉴스</span>
                    </div>
                    <p class="tit">「포켓몬스터」 시리즈 최신작의 발매일이 결정되었습니다.</p>
                    <p class="releaseInfo">2021.05.26<br>Nintendo Switch</p>
                </div>
            


            <a href="/news/list.php" class="more_view">더보기</a>
        </div>
        <!-- //inner end -->
    </div>
    <!-- //inner end -->
    </div><!-- //news_list end -->

    <div class="row_banner">
        <a href="https://store.nintendo.co.kr/nintendo-ecash" onmousedown="javascript:ACEL_TRACKING_10('BC','10');" class="banner_eshop" target="_blank">닌텐도 선불 번호 구입</a>
    </div><!-- //banner end -->

    <div class="software_wrap article inner">
        <h2 class="main_h2">주요 소프트웨어<span class="desc">Game Title</span></h2>

        <div class="newSw_cate software_list software_set_01 typeB clearfix" id="mailSwList">
            <!-- 로딩바 -->
            <!-- <div class='loadingBox'><img src='/images/renew/common/ico_loader.gif' alt='로딩중' /></div> -->
            <!-- // 로딩바 -->
                            <div class="sw_item item icon ico_new">
                    <a href="/software/switch/aw8sa/"
                        class="thumb">
                        <img src="/front_images/sw/switch/1120/94b561646a683f0a507baaf8c2564b0d.jpg" alt="" loading="lazy">
                    </a>
                    <div>
                        <span class="cate">Nintendo Switch</span>
                        <span class="type">
    						                                <strong class="ico_rel">PK</strong>
                                <strong class="ico_rel">DL</strong>
                                					</span>
                    </div>
                    <p class="tit">미토피아</p>
                    <p class="releaseInfo">2021.05.21 <br>한국닌텐도</p>
                                            <p class="ico_lang ko">한국어 대응</p>
                                    </div>
                            <div class="sw_item item icon ">
                    <a href="/software/switch/detail/arfta/"
                        class="thumb">
                        <img src="/front_images/sw/switch/1163/c18c50d75cc41457500051c0b0d33063.jpg" alt="" loading="lazy">
                    </a>
                    <div>
                        <span class="cate">Nintendo Switch</span>
                        <span class="type">
    						                                <strong class="ico_rel">PK</strong>
                                <strong class="ico_rel">DL</strong>
                                					</span>
                    </div>
                    <p class="tit">New 포켓몬 스냅</p>
                    <p class="releaseInfo">2021.04.30 <br>한국닌텐도</p>
                                            <p class="ico_lang ko">한국어 대응</p>
                                    </div>
                            <div class="sw_item item icon ">
                    <a href="/software/switch/auzpa/"
                        class="thumb">
                        <img src="/front_images/sw/switch/1035/e7c170fe5228a3be04d94f231550f185.jpg" alt="" loading="lazy">
                    </a>
                    <div>
                        <span class="cate">Nintendo Switch</span>
                        <span class="type">
    						                                <strong class="ico_rel">PK</strong>
                                <strong class="ico_rel">DL</strong>
                                					</span>
                    </div>
                    <p class="tit">슈퍼 마리오 3D 월드 + 퓨리 월드</p>
                    <p class="releaseInfo">2021.02.12 <br>한국닌텐도</p>
                                            <p class="ico_lang ko">한국어 대응</p>
                                    </div>
                            <div class="sw_item item icon ">
                    <a href="/software/switch/rmaaa/"
                        class="thumb">
                        <img src="/front_images/sw/switch/1000/8b35af4cd55cf18327f5fbff56147d1e.jpg" alt="" loading="lazy">
                    </a>
                    <div>
                        <span class="cate">Nintendo Switch</span>
                        <span class="type">
    						                                <strong class="ico_rel">PK</strong>
                                					</span>
                    </div>
                    <p class="tit">마리오 카트 라이브: 홈 서킷</p>
                    <p class="releaseInfo">2020.12.17 <br>한국닌텐도</p>
                                            <p class="ico_lang ko">한국어 대응</p>
                                    </div>
                            <div class="sw_item item icon ">
                    <a href="https://nintendo.co.kr/software/switch/axeab/"
                        class="thumb">
                        <img src="/front_images/sw/switch/957/dd0ac3cbe56350b36bf5dd9cb46d5324.jpg" alt="" loading="lazy">
                    </a>
                    <div>
                        <span class="cate">Nintendo Switch</span>
                        <span class="type">
    						                                <strong class="ico_rel">PK</strong>
                                <strong class="ico_rel">DL</strong>
                                					</span>
                    </div>
                    <p class="tit">젤다무쌍 대재앙의 시대</p>
                    <p class="releaseInfo">2020.11.20 <br>한국닌텐도</p>
                                            <p class="ico_lang ko">한국어 대응</p>
                                    </div>
                            <div class="sw_item item icon ">
                    <a href="/software/switch/acbaa/"
                        class="thumb">
                        <img src="/front_images/sw/switch/469/469.jpg" alt="" loading="lazy">
                    </a>
                    <div>
                        <span class="cate">Nintendo Switch</span>
                        <span class="type">
    						                                <strong class="ico_rel">PK</strong>
                                <strong class="ico_rel">DL</strong>
                                					</span>
                    </div>
                    <p class="tit">모여봐요 동물의 숲</p>
                    <p class="releaseInfo">2020.03.20 <br>한국닌텐도</p>
                                            <p class="ico_lang ko">한국어 대응</p>
                                    </div>
                            <div class="sw_item item icon ">
                    <a href="/software/switch/sword_shield/"
                        class="thumb">
                        <img src="/front_images/sw/switch/442/442.jpg" alt="" loading="lazy">
                    </a>
                    <div>
                        <span class="cate">Nintendo Switch</span>
                        <span class="type">
    						                                <strong class="ico_rel">PK</strong>
                                <strong class="ico_rel">DL</strong>
                                					</span>
                    </div>
                    <p class="tit">포켓몬스터소드 · 실드</p>
                    <p class="releaseInfo">2019.11.15 <br>한국닌텐도</p>
                                            <p class="ico_lang ko">한국어 대응</p>
                                    </div>
                            <div class="sw_item item icon ">
                    <a href="/software/switch/ring"
                        class="thumb">
                        <img src="/front_images/sw/switch/427/427.jpg" alt="" loading="lazy">
                    </a>
                    <div>
                        <span class="cate">Nintendo Switch</span>
                        <span class="type">
    						                                <strong class="ico_rel">PK</strong>
                                					</span>
                    </div>
                    <p class="tit">링 피트 어드벤처</p>
                    <p class="releaseInfo">2019.10.18 <br>한국닌텐도</p>
                                            <p class="ico_lang ko">한국어 대응</p>
                                    </div>
            
        </div><!-- //software list2 end -->
    </div><!-- //software end -->

    <div class="banner_wrap clearfix inner">
        <!-- 배너가 2개인 왼쪽은 left 오른쪽은 right 클래스 추가 -->
        <!--
            <div class="banner list_3" style="background-image: url(video//);"><a href="#" class="openVideo" data-idx=""></a></div>
        -->
        <div class="banner list_3"><a href="https://ac-pocketcamp.com/ko-KR" target="_blank"></a></div>
        <div class="banner list_3"><a href="/guide/software/"></a></div>
        <div class="banner list_3"><a href="https://youtube.com/playlist?list=PL4GwDymg3a1Sf5L28aOvoNoIgMS3dUh1y" target="_blank"></a></div>

    </div><!-- //banner end -->

    <div class="banner_wrap clearfix inner new-banner">
        <!-- 20.10.19 신규 배너 3개 추가 -->

        <div class="banner list_3"><a href="#" class="openVideo" data-idx="6-cFpaS1ofs"></a></div>
<!--        <div class="banner list_3"><a href="/news/view.php?no=SEF1cTJCRU9PU3RSYkVyNStOMDJjdz09"></a></div>-->
        <div class="banner list_3"><a href="#" class="openVideo" data-idx="UTQ_QZad3RM"></a></div>
        <div class="banner list_3"><a href="#" class="openVideo" data-idx="3mXqTKGnYfc"></a></div>

    </div><!-- //banner end -->

    <div class="online_store inner article">
        <h2 class="etc">쉽고 간편한 다운로드 버전으로도 <br>즐길 수 있습니다.</h2>

        <ul class="st_tbl_border cell_3 picto_list clearfix">
            <li><a href="https://store.nintendo.co.kr/" onmousedown="javascript:ACEL_TRACKING_9('BC','9');" target="_blank"><span class="r_arrow">다운로드 구입하기</span></a></li>
            <li><a href="/support/switch/eshop/howtodl/prepaidcard/index.php"><span class="r_arrow">Nintendo Switch / 닌텐도 3DS<br>닌텐도 선불 카드 안내</span></a></li>
            <li><a href="https://store.nintendo.co.kr/nintendo-ecash" target="_blank"><span class="r_arrow">Nintendo Switch<br>닌텐도 선불 번호 구입하기</span></a></li>
        </ul>
    </div><!-- //online_store end -->

    <div class="news_ticker_wrap inner">
        <div class="tit">알려 드립니다<a href="/news/list.php?cate=3" class="more_view more_view_typeB">더 보기</a></div>
        <div class="news_ticker clearfix">
                            <div class="item li_st_cir">
                                            <a href="/news/view.php?no=Z0lEQlVFblU0SXBaVmdwNEpKaElOZz09" target="_self">
                                                「Fire Emblem: Shadow Dragon & the Blade of Light」의 판매 종료 안내                        </a>
                </div>
                            <div class="item li_st_cir">
                                            <a href="/3DS/customer/re_exchange_diary/index.php" target="_self">
                                                어느새 교환 일기 리마스터 버전 배포 안내                        </a>
                </div>
                    </div>

    </div>
</section>

<!-- layer popup -->
<div class="layer_popup">
    <div class="innerWrap">
        <div class="videoWrap"></div>

        <a href="#" class="btn_close_layer_popup" onclick="closeLayerPopup(); return false;"><img src="/images/renew/common/btn_close_layer_popup.gif" alt="닫기"></a>
    </div>
    <!--//innerWrap end -->
</div>
<!-- //layer_popup end -->

<!-- navicator -->
<div class="navi">
    <div class="inner">
        <h1 class="logo_nintendo_red">Nintendo</h1>
        <a href="#" class="btn_gotoTop">top으로 이동</a>
    </div>
</div>


<!-- loading -->
<div class="loading"></div>

<!-- video popup -->
<div class="dim"></div>

<script>
    $(document).ready(function(){
        //main slider
        var mainSlide = $('.main_slide');
        var lLength = document.querySelectorAll('.main_slide .item').length;


        mainSlide.owlCarousel({
            items:1,
            loop:true,
            rewind: false,
            nav:true,
            dots:false,
            autoplay:true,
            autoplayTimeout:4000,
            autoplaySpeed:1000,
            //animateOut: 'bounceIn',
            //animateIn: 'bounceIn'
            callback: true,
        });

        $('.num-nav .maxLength').text(lLength);

        mainSlide.on('translated.owl.carousel', function (e) {
            var activeItem = $('.owl-stage-outer .active').find('.item').data('num');

            $('.num-nav .now').text(activeItem);
        });




        $(".openVideo").on("click",function(e){
            e.preventDefault();

            var videoId = $(this).attr("data-idx");
            $(".videoWrap").html("<iframe width='640' height='360' src='https://www.youtube.com/embed/"+videoId+"?autoplay=1&rel=0' frameborder='0' gesture='media' allow='encrypted-media' allowfullscreen></iframe>");

            openLayerPopup();
        })

        $(".btn_close_layer_popup").on("click",function(e){
            e.preventDefault();
            $(".videoWrap").html("");
        })
    })

    $(window).load(function(){
        // 닌텐도로 즐겨요 slider(모바일)
        if(winWidth<768){
            main_software();
        }

        news();
    })

    $(window).resize(function(){
        if(winWidth<768){
            main_software();
        }else{
            destroy_main_software();
        }

        news();
    })

    function destroy_main_software(){
        $(".software_list").trigger('destroy.owl.carousel');
        $(".software_list").removeClass("owl-carousel owl-theme");
        if(winWidth>1180){
            $(".software_set_01 .sw_item").width("276");
        }else{
            $(".software_set_01 .sw_item").css("width","calc((100% - 60px)/4)");
        }
    }

    function main_software(){
        var imgWidth = winWidth - 80;
        $(".software_set_01 .sw_item").width(imgWidth);

        $(".software_list").addClass("owl-carousel owl-theme");

        $(".software_list").trigger('destroy.owl.carousel');
        $(".software_list").owlCarousel({
            items:1,
            margin:10,
            loop:true,
            center:true,
            autoWidth:true,
            dots:false
        })
    }

    function news(){
        if(winWidth<1025){
            if($(".news_ticker div").length >= 2){
                $(".news_ticker").trigger('destroy.owl.carousel');
                $(".news_ticker").addClass("owl-carousel owl-theme");
                $(".news_ticker").owlCarousel({
                    items:1,
                    loop:true,
                    dots:false,
                    autoplay:true,
                    animateOut: 'slideOutUp',
                    animateIn: 'slideInUp',
                    autoWidth: false
                })
            }
        }else{
            $(".news_ticker").trigger('destroy.owl.carousel');
            $(".news_ticker").removeClass("owl-carousel owl-theme");
        }
    }



</script>



<!-- bottom -->
<section class="bottom">
    <div class="inner">
        <div class="link">
            <ul class="sns">
                <li><a class="ico_youtube" href="https://www.youtube.com/channel/UCRCK5FCJtomQT3b88jXI_DA" target="_blank">유튜브</a></li>
                <li><a class="ico_kakaoStory" href="https://story.kakao.com/ch/nintendokorea/" target="_blank">카카오스토리</a></li>
                <li><a class="ico_facebook" href="https://www.facebook.com/Nintendo.kr" target="_blank">페이스북</a></li>
                <!--li><a class="ico_twitter" href="https://twitter.com/Nintendo_Korea" target="_blank">트위터</a></li-->
            </ul>
            <div class="btnBox">
                <a class="ico_myNintendo" href="https://my.nintendo.com/" target="_blank">My Nintendo</a>
                <a class="ico_amiibo" href="/amiibo/" target="_blank">amiibo</a>
            </div>
        </div>
        <!-- //link end -->
    </div>
    <!-- //inner end -->

    <div class="bottom_nav">
        <ul>
            <li>
                <a href="#">한국닌텐도</a>
                <ul>
                    <li><a href="/corporate/kr/kr01.html">- 회사개요</a></li>
                    <li><a href="/corporate/kr/kr04.html">- 찾아오시는 길</a></li>
                </ul>
            </li>
            <li>
                <a href="#">본체 / amiibo</a>
                <ul>
                    <li><a href="/switch/index.php">- Nintendo Switch</a></li>
                    <li><a href="/n3ds/new_3dsXl.php">- New 닌텐도 3DS XL</a></li>
                    <li><a href="/n3ds/new_2dsXl.php">- New 닌텐도 2DS XL</a></li>
                    <li><a href="/amiibo/index.php">- amiibo</a></li>
                </ul>
            </li>
            <li>
                <a href="#">소프트웨어</a>
                <ul>
                    <li><a href="/software/switch/index.php">- Nintendo Switch 소프트웨어</a></li>
                    <li><a href="/software/3ds/index.php">- 닌텐도 3DS 소프트웨어</a></li>
                    <li><a href="/software/release/">- 발매 예정 소프트웨어</a></li>
                    <li><a href="/software/smartphone/">- 스마트폰용 앱</a></li>
                </ul>
            </li>
            <li>
                <a href="#">고객지원</a>
                <ul>
                    <li><a href="/support/switch/index.php">- Nintendo Switch</a></li>
                    <li><a href="/3DS/customer/index.php">- 닌텐도 3DS</a></li>
                    <li><a href="https://support.nintendo.co.kr/index.do" target="_blank">- 고객지원 홈페이지</a></li>
                </ul>
            </li>
        </ul>
    </div>
    <!-- //bottom_nav end -->
</section>
<!-- //bottom end -->

<!-- footer -->
<footer>
    <div class="inner">
        <div class="btnTerms">
            <a href="/common/account.php">이용약관</a>
            <a href="/common/privacy.php">개인정보취급방침</a>
        </div>
        <p class="f_cs_info">고객지원 문의전화 : 1670-9900 <span class="bl_m">(평일 오전 9시 30분~오후 5시 30분)</span><span class="bl">※ 토/일/공휴일/회사 정기휴일 및 특별휴일 제외</span></p>

        <address>ⓒ 2006 Nintendo of Korea Co., Ltd. All Rights Reserved.<br/>
            <span>상호명 : 한국닌텐도주식회사</span>
            <span>대표자명 : 미우라 타카히로</span>
            사업자등록번호 : 120-87-03578</address>
    </div>
    <!-- //inner end -->
</footer>
<!-- //footer -->



<!-- 2019.12.03 레이어 팝업 추가 -->

<!-- 여기부터 모바일용 -->

<script>
    var cookieData = document.cookie;
    var fabricated = cookieData.replace(/ /gi, ""); // 공백제거
    var fabricatedCookieData = fabricated.split(';'); // 세미콜론을 기준으로 문자열 쪼개기 (배열에 담김)
    var finalFabricated = [];

    for (var i = 0; i < fabricatedCookieData.length; i++ ){
        finalFabricated[i] = fabricatedCookieData[i].split('=');
    }

    if (finalFabricated.length > 0) {
        for (var k = 0; k < finalFabricated.length; k++ ){
            $('#' + finalFabricated[k][0]).remove(); // PC 슬라이드 제거
            $('.slide-item[data-idx="'+ finalFabricated[k][0]+'"]').remove(); // 모바일 슬라이드 제거
        }
    }

    function setCookie( name, value, expiredays ) {
        var todayDate = new Date();
        todayDate.setDate( todayDate.getDate() + expiredays );
        document.cookie = name + "=" + escape( value ) + "; path=/; expires=" + todayDate.toGMTString() + ";"
        $('#'+ name).remove();
        $('.slide-item[data-idx="'+ name+'"]').remove();
    }

    function closeWin(target) {
        $('#'+ target).remove();
    }

    function todaycloseWin(cookieName) {
        setCookie(cookieName, "done", 1);
    }

    var active_num = 0; // 슬라이드 초기값
    var total_slide = 0; // 팝업 슬라이드 초기값
    function notToday(e) {
        var d = $(e).closest('.layer-inner').find('.active').find('.slide-item').attr('data-idx');

        layerPopMo.trigger('remove.owl.carousel', active_num);
        layerPopMo.trigger('refresh.owl.carousel');


        setCookie(d, "done", 1);
        $("#"+ d).remove();


        if (total_slide === 0) {
            closeWin('no_more_mo');
        }
    }

    function callback(event) {
        var item = event.item.index; // active 된 슬라이드의 인덱스 번호
        var items = event.item.count; // 팝업 슬라이드의 아이템 갯수

        active_num = item;
        total_slide = items;
    }

    var length_length = $('.layer-inner .slide-item').length;
    var layerPopMo = $('.layer_popup_main.current_mo .owl-carousel');

    $(window).load(function () {
        layerPopMo.owlCarousel({
            items: 1,
            loop: false,
            nav: false,
            dots: true,
            autoHeight: true,
            onRefresh: callback,
            onChanged: callback,
            onInitialize: callback,
        });
        $('.loading-box').fadeOut();
        $('.owl-carousel').fadeIn();
    });

    layerPopMo.trigger('refresh.owl.carousel');

    if (length_length === 0) {
        closeWin('no_more_mo');
    }
</script>



<!-- acecounter 2018.02.26 -->
<script language='javascript'> 
	var _skey = '';
	</script>
<script language='javascript'>
var _AceGID=(function(){var Inf=['gtp13.acecounter.com','8080','AH3A39994163732','AW','0','NaPm,Ncisy','ALL','0']; var _CI=(!_AceGID)?[]:_AceGID.val;var _N=0;var _T=new Image(0,0);if(_CI.join('.').indexOf(Inf[3])<0){ _T.src ="https://"+ Inf[0] +'/?cookie'; _CI.push(Inf);  _N=_CI.length; } return {o: _N,val:_CI}; })();
var _AceCounter=(function(){var G=_AceGID;var _sc=document.createElement('script');var _sm=document.getElementsByTagName('script')[0];if(G.o!=0){var _A=G.val[G.o-1];var _G=(_A[0]).substr(0,_A[0].indexOf('.'));var _C=(_A[7]!='0')?(_A[2]):_A[3];var _U=(_A[5]).replace(/\,/g,'_');_sc.src='https:'+'//cr.acecounter.com/Web/AceCounter_'+_C+'.js?gc='+_A[2]+'&py='+_A[4]+'&gd='+_G+'&gp='+_A[1]+'&up='+_U+'&rd='+(new Date().getTime());_sm.parentNode.insertBefore(_sc,_sm);return _sc.src;}})();
</script>
<noscript><img src='https://gtp13.acecounter.com:8080/?uid=AH3A39994163732&je=n&' border='0' width='0' height='0' alt=''></noscript>	
<!-- AceCounter Log Gathering Script End -->

<script type="text/javascript">
    var sdkInstance="appInsightsSDK";window[sdkInstance]="appInsights";var aiName=window[sdkInstance],aisdk=window[aiName]||function(e){function n(e){t[e]=function(){var n=arguments;t.queue.push(function(){t[e].apply(t,n)})}}var t={config:e};t.initialize=!0;var i=document,a=window;setTimeout(function(){var n=i.createElement("script");n.src=e.url||"https://az416426.vo.msecnd.net/scripts/b/ai.2.min.js",i.getElementsByTagName("script")[0].parentNode.appendChild(n)});try{t.cookie=i.cookie}catch(e){}t.queue=[],t.version=2;for(var r=["Event","PageView","Exception","Trace","DependencyData","Metric","PageViewPerformance"];r.length;)n("track"+r.pop());n("startTrackPage"),n("stopTrackPage");var s="Track"+r[0];if(n("start"+s),n("stop"+s),n("setAuthenticatedUserContext"),n("clearAuthenticatedUserContext"),n("flush"),!(!0===e.disableExceptionTracking||e.extensionConfig&&e.extensionConfig.ApplicationInsightsAnalytics&&!0===e.extensionConfig.ApplicationInsightsAnalytics.disableExceptionTracking)){n("_"+(r="onerror"));var o=a[r];a[r]=function(e,n,i,a,s){var c=o&&o(e,n,i,a,s);return!0!==c&&t["_"+r]({message:e,url:n,lineNumber:i,columnNumber:a,error:s}),c},e.autoExceptionInstrumented=!0}return t}(
        {
            instrumentationKey:"16f136cc-cc1e-4b8b-a3da-a6a775139013"
        }
    );window[aiName]=aisdk,aisdk.queue&&0===aisdk.queue.length&&aisdk.trackPageView({});
</script>

</body>
</html>
